import json
import re

with open('lepidolite_price_history.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

history = data['history']
print(f'修复前总记录数: {len(history)}')

# 找所有有unit字段且unit包含'元/吨'的记录（可能是'元/吨度'）
to_fix = [i for i, r in enumerate(history) if 'unit' in r and '元/吨' in r.get('unit', '')]
print(f'需要修复的记录数: {len(to_fix)}')

for idx in to_fix:
    r = history[idx]
    unit = r['unit']
    grade = r.get('grade', '')
    # 从grade中提取品位数字，如'锂云母精矿2.5%' -> 2.5
    m = re.search(r'(\d+\.?\d*)%', grade)
    grade_pct = float(m.group(1)) if m else 2.5  # 默认2.5%
    
    old_min = r['min_price']
    old_max = r['max_price']
    old_avg = r['avg_price']
    
    # 转换: 元/吨度 -> 万元/吨 (除以10000，乘以品位%)
    r['min_price'] = round(r['min_price'] * grade_pct / 10000, 6)
    r['max_price'] = round(r['max_price'] * grade_pct / 10000, 6)
    r['avg_price'] = round(r['avg_price'] * grade_pct / 10000, 6)
    r['unit'] = '万元/吨'
    
    print(f'  修复: date={r["date"]}, grade={grade}, 品位={grade_pct}%')
    print(f'    旧: min={old_min}, max={old_max}, avg={old_avg}, unit={unit}')
    print(f'    新: min={r["min_price"]}, max={r["max_price"]}, avg={r["avg_price"]}, unit={r["unit"]}')

# 保存
with open('lepidolite_price_history.json', 'w', encoding='utf-8') as f:
    json.dump(data, f, ensure_ascii=False, indent=2)

print('修复完成，已保存')
print(f'修复后总记录数: {len(data["history"])}')
